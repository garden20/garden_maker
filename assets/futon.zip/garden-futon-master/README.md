garden-futon
============

A couchdb futon that plays well with the garden.

This is just a slightly modified version of futon that ships with couchdb 1.2. It simply adds the links for the garden dashboard.
To add to your couch, simply copy over the files like this:

`cp -r * ~/garden/CouchDB\ Server.app/Contents/Resources/couchdbx-core/share/couchdb/www/`